#!/bin/bash

# Bash wrapper for qfp_config_tool.py
# Handles dependency installation and provides user-friendly output

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Color codes for output (ASCII-compatible for macOS)
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if Python is available
check_python() {
    if command -v python3 &> /dev/null; then
        PYTHON_CMD="python3"
        return 0
    elif command -v python &> /dev/null; then
        PYTHON_CMD="python"
        return 0
    else
        print_error "Python is not installed or not in PATH"
        return 1
    fi
}

# Function to check and install dependencies
check_dependencies() {
    print_info "Checking Python dependencies..."
    
    # Check if PyYAML is installed
    if ! $PYTHON_CMD -c "import yaml" &> /dev/null; then
        print_warning "PyYAML not found. Installing..."
        $PYTHON_CMD -m pip install --break-system-packages pyyaml &> /dev/null || \
        $PYTHON_CMD -m pip install pyyaml &> /dev/null || {
            print_error "Failed to install PyYAML"
            print_info "Please install it manually: pip install pyyaml"
            return 1
        }
        print_success "PyYAML installed successfully"
    fi
    
    return 0
}

# Function to find the Python script
find_python_script() {
    print_info "Searching for qfp_config_tool.py..."
    
    # Priority 1: Same directory as this script
    if [ -f "${SCRIPT_DIR}/qfp_config_tool.py" ]; then
        PYTHON_SCRIPT="${SCRIPT_DIR}/qfp_config_tool.py"
        print_info "Found at: ${PYTHON_SCRIPT}"
        return 0
    fi
    
    # Priority 2: ~/bin directory (common location for user scripts)
    if [ -f "$HOME/bin/qfp_config_tool.py" ]; then
        PYTHON_SCRIPT="$HOME/bin/qfp_config_tool.py"
        print_info "Found at: ${PYTHON_SCRIPT}"
        return 0
    fi
    
    # Priority 3: Current working directory
    if [ -f "./qfp_config_tool.py" ]; then
        PYTHON_SCRIPT="./qfp_config_tool.py"
        print_info "Found at: ${PYTHON_SCRIPT}"
        return 0
    fi
    
    # Priority 4: /mnt/project (for Claude environment)
    if [ -f "/mnt/project/qfp_config_tool.py" ]; then
        PYTHON_SCRIPT="/mnt/project/qfp_config_tool.py"
        print_info "Found at: ${PYTHON_SCRIPT}"
        return 0
    fi
    
    print_error "Python script not found: qfp_config_tool.py"
    print_info "Searched in:"
    print_info "  - ${SCRIPT_DIR}"
    print_info "  - $HOME/bin"
    print_info "  - $(pwd)"
    print_info "Please ensure qfp_config_tool.py is in one of these locations"
    return 1
}

# Function to display usage
usage() {
    cat << EOF
Usage: $(basename "$0") <command> [options]

Commands:
  list <config_file> [--all]            List deployments and tests
  cleanup <config_file> [options]       Cleanup and optimize YAML structure
  update <config_file> [options]        Update configuration values

List Options:
  --all                                 Show all items including disabled ones
  --resources                           Show resource values (cpu-min, cpu-max, memory-min, memory-max)

Cleanup Options:
  --output <file>                       Output file (default: input file with .cleaned.yml suffix)
  --dry-run                             Show what would be done without making changes

Update Options:
  --auto-pause <true|false>             Set auto-pause value
  --disabled <true|false>               Set disabled value
  --deployment-strategy <Recreate|RollingUpdate>
                                        Set deployment strategy
  --cpu-min <value>                     Set minimum CPU (e.g., 500m, 1000m)
  --cpu-max <value>                     Set maximum CPU (e.g., 2000m, 4000m)
  --memory-min <value>                  Set minimum memory (e.g., 512Mi, 1Gi)
  --memory-max <value>                  Set maximum memory (e.g., 2Gi, 4Gi)
  --remove <auto-pause|disabled|deployment-strategy>
                                        Remove a parameter from items
  --plans <plan1,plan2,...>             Comma-separated list of plan names (default: all)

Examples:
  # List enabled deployments
  $(basename "$0") list service-datascience-gateway-ga.yml

  # List all deployments including disabled
  $(basename "$0") list service-datascience-gateway-ga.yml --all

  # List with resource values
  $(basename "$0") list service-datascience-gateway-ga.yml --resources

  # List all deployments with resources
  $(basename "$0") list service-datascience-gateway-ga.yml --all --resources

  # Analyze YAML structure (dry run)
  $(basename "$0") cleanup service-author-intentions-model-staging.yml --dry-run

  # Cleanup and optimize YAML structure
  $(basename "$0") cleanup service-author-intentions-model-staging.yml

  # Cleanup with custom output file
  $(basename "$0") cleanup service-author-intentions-model-staging.yml --output optimized.yml

  # Update auto-pause to false for all plans
  $(basename "$0") update service-datascience-gateway-ga.yml --auto-pause false

  # Update deployment strategy for specific plans
  $(basename "$0") update service-datascience-gateway-ga.yml --deployment-strategy RollingUpdate --plans 5-ga-deploy

  # Update resource values
  $(basename "$0") update service-datascience-gateway-ga.yml --cpu-min 1000m --memory-max 4Gi --plans 5-ga-deploy

  # Update multiple resource fields
  $(basename "$0") update service-datascience-gateway-ga.yml --memory-min 2Gi --memory-max 8Gi

  # Remove a parameter
  $(basename "$0") update service-datascience-gateway-ga.yml --remove auto-pause --plans 5-ga-deploy

  # Update multiple fields at once
  $(basename "$0") update service-datascience-gateway-ga.yml --auto-pause false --disabled false --deployment-strategy Recreate --cpu-min 1000m --plans 5-ga-deploy

EOF
}

# Main script
main() {
    # Check if no arguments provided
    if [ $# -eq 0 ]; then
        usage
        exit 1
    fi
    
    # Check Python availability
    if ! check_python; then
        exit 1
    fi
    
    # Find the Python script
    if ! find_python_script; then
        exit 1
    fi
    
    # Check dependencies
    if ! check_dependencies; then
        exit 1
    fi
    
    # Add separator for cleaner output
    echo ""
    echo "============================================================"
    
    # Run the Python script with all arguments
    $PYTHON_CMD "$PYTHON_SCRIPT" "$@"
    EXIT_CODE=$?
    
    # Add separator at the end
    echo "============================================================"
    echo ""
    
    # Display success or error message based on exit code
    if [ $EXIT_CODE -eq 0 ]; then
        print_success "Operation completed successfully"
    else
        print_error "Operation failed with exit code $EXIT_CODE"
    fi
    
    return $EXIT_CODE
}

# Run main function with all arguments
main "$@"
