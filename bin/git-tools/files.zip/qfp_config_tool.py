#!/usr/bin/env python3
"""
General-purpose deployment configuration tool.

Usage:
    # List enabled deployments and tests
    python deployment_config_tool.py list <config_file>
    
    # Update auto-pause value for all deployments in specified plans
    python deployment_config_tool.py update <config_file> --auto-pause <true|false> [--plans PLAN1,PLAN2,...]
    
Examples:
    python deployment_config_tool.py list service-datascience-gateway-ga.yml
    python deployment_config_tool.py update service-datascience-gateway-ga.yml --auto-pause false
    python deployment_config_tool.py update service-datascience-gateway-ga.yml --auto-pause true --plans 5-ga-deploy,7-sales-deploy
"""

import sys
import yaml
import argparse
from pathlib import Path
from typing import Dict, Any, List


def load_yaml(file_path: Path) -> Dict[str, Any]:
    """Load YAML file."""
    with open(file_path, 'r') as f:
        return yaml.safe_load(f)


def get_all_items(plan: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
    """
    Extract all deployments and tests from a plan.
    Returns a dictionary with plan names as keys and lists of item info as values.
    Each item is a dict with 'name', optionally 'target' (for tests), 'auto-pause', 'disabled', 
    and 'deployment-strategy' values.
    """
    all_items = {}
    
    for plan_name, items in plan.items():
        if not isinstance(items, list):
            continue
        
        item_info_list = []
        for item in items:
            name = item.get('name', 'unnamed')
            target = item.get('config', {}).get('target', None)
            auto_pause = item.get('auto-pause', None)
            is_disabled = item.get('disabled', False)
            
            # Extract deployment strategy
            deployment_strategy = None
            config = item.get('config', {})
            if 'deployment-strategy' in config:
                strategy = config['deployment-strategy']
                if isinstance(strategy, dict):
                    strategy_type = strategy.get('type', 'Unknown')
                    if strategy_type == 'Recreate':
                        deployment_strategy = 'Recreate'
                    elif strategy_type == 'RollingUpdate':
                        deployment_strategy = 'RollingUpdate'
                    else:
                        deployment_strategy = strategy_type
            
            # Extract resources
            resources = None
            if 'resources' in config:
                resources = config['resources']
            
            item_info = {
                'name': name,
                'disabled': is_disabled
            }
            if target:
                item_info['target'] = target
            if auto_pause is not None:
                item_info['auto-pause'] = auto_pause
            if deployment_strategy is not None:
                item_info['deployment-strategy'] = deployment_strategy
            if resources is not None:
                item_info['resources'] = resources
            item_info_list.append(item_info)
        
        if item_info_list:
            all_items[plan_name] = item_info_list
    
    return all_items


def get_enabled_items(plan: Dict[str, Any]) -> Dict[str, List[Dict[str, str]]]:
    """
    Extract enabled deployments and tests from a plan.
    Returns a dictionary with plan names as keys and lists of enabled item info as values.
    Each item is a dict with 'name', optionally 'target' (for tests), and 'auto-pause' value.
    """
    all_items = get_all_items(plan)
    enabled_items = {}
    
    for plan_name, items in all_items.items():
        enabled_item_info = [item for item in items if not item['disabled']]
        if enabled_item_info:
            enabled_items[plan_name] = enabled_item_info
    
    return enabled_items


def check_deployment_test_mismatch(enabled_items: Dict[str, List[Dict[str, str]]]) -> List[str]:
    """
    Check if there are mismatches between deployment and test counts,
    and verify that tests have corresponding deployments.
    Returns a list of warning messages.
    """
    warnings = []
    
    # Define deployment/test pairs to check
    # Format: (deploy_plan_name, test_plan_name, environment_name)
    pairs = [
        ('1-sandbox-deploy', '2-sandbox-test', 'Sandbox'),
        ('3-uat-deploy', '4-uat-test', 'UAT'),
        ('5-ga-deploy', '6-ga-test', 'GA'),
        ('7-sales-deploy', '8-sales-test', 'Sales'),
    ]
    
    for deploy_plan, test_plan, env_name in pairs:
        deploy_items = enabled_items.get(deploy_plan, [])
        test_items = enabled_items.get(test_plan, [])
        
        deploy_count = len(deploy_items)
        test_count = len(test_items)
        
        # Only check if at least one of them exists
        if deploy_count > 0 or test_count > 0:
            # Check count mismatch
            if deploy_count != test_count:
                warnings.append(
                    f"[WARNING] {env_name} count mismatch: "
                    f"{deploy_count} enabled deployments but {test_count} enabled tests"
                )
            
            # Check target correlation
            deploy_names = {item['name'] for item in deploy_items}
            
            # Find tests without matching deployments
            orphaned_tests = []
            for test_item in test_items:
                target = test_item.get('target')
                if target and target not in deploy_names:
                    orphaned_tests.append(f"{test_item['name']} (target: {target})")
            
            if orphaned_tests:
                warnings.append(
                    f"[WARNING] {env_name} tests without matching deployment targets:"
                )
                for orphan in orphaned_tests:
                    warnings.append(f"  - {orphan}")
            
            # Find deployments without matching tests
            test_targets = {item.get('target') for item in test_items if item.get('target')}
            untested_deploys = []
            for deploy_item in deploy_items:
                if deploy_item['name'] not in test_targets:
                    untested_deploys.append(deploy_item['name'])
            
            if untested_deploys:
                warnings.append(
                    f"[WARNING] {env_name} deployments without matching tests:"
                )
                for untested in untested_deploys:
                    warnings.append(f"  - {untested}")
    
    return warnings


def update_auto_pause(config: Dict[str, Any], auto_pause_value: bool, plan_names: List[str] = None) -> Dict[str, int]:
    """
    Update auto-pause values in deployment plans.
    
    Args:
        config: Configuration dictionary
        auto_pause_value: Value to set for auto-pause (True/False)
        plan_names: List of specific plan names to update (if None, updates all plans)
    
    Returns:
        Dictionary with statistics about updates made
    """
    stats = {'total_updated': 0, 'plans_affected': 0}
    plan = config.get('plan', {})
    
    if not plan:
        return stats
    
    # Determine which plans to update
    plans_to_update = plan_names if plan_names else list(plan.keys())
    
    for plan_name in plans_to_update:
        if plan_name not in plan:
            print(f"[WARNING] Plan '{plan_name}' not found in configuration")
            continue
        
        items = plan[plan_name]
        if not isinstance(items, list):
            continue
        
        plan_updated = False
        for item in items:
            if isinstance(item, dict):
                old_value = item.get('auto-pause')
                item['auto-pause'] = auto_pause_value
                if old_value != auto_pause_value:
                    stats['total_updated'] += 1
                    plan_updated = True
        
        if plan_updated:
            stats['plans_affected'] += 1
    
    return stats


def update_disabled(config: Dict[str, Any], disabled_value: bool, plan_names: List[str] = None) -> Dict[str, int]:
    """
    Update disabled values in deployment plans.
    
    Args:
        config: Configuration dictionary
        disabled_value: Value to set for disabled (True/False)
        plan_names: List of specific plan names to update (if None, updates all plans)
    
    Returns:
        Dictionary with statistics about updates made
    """
    stats = {'total_updated': 0, 'plans_affected': 0}
    plan = config.get('plan', {})
    
    if not plan:
        return stats
    
    # Determine which plans to update
    plans_to_update = plan_names if plan_names else list(plan.keys())
    
    for plan_name in plans_to_update:
        if plan_name not in plan:
            print(f"[WARNING] Plan '{plan_name}' not found in configuration")
            continue
        
        items = plan[plan_name]
        if not isinstance(items, list):
            continue
        
        plan_updated = False
        for item in items:
            if isinstance(item, dict):
                old_value = item.get('disabled')
                item['disabled'] = disabled_value
                if old_value != disabled_value:
                    stats['total_updated'] += 1
                    plan_updated = True
        
        if plan_updated:
            stats['plans_affected'] += 1
    
    return stats


def update_deployment_strategy(config: Dict[str, Any], strategy_type: str, plan_names: List[str] = None) -> Dict[str, int]:
    """
    Update deployment-strategy values in deployment plans.
    
    Args:
        config: Configuration dictionary
        strategy_type: Type of deployment strategy ('Recreate' or 'RollingUpdate')
        plan_names: List of specific plan names to update (if None, updates all plans)
    
    Returns:
        Dictionary with statistics about updates made
    """
    stats = {'total_updated': 0, 'plans_affected': 0}
    plan = config.get('plan', {})
    
    if not plan:
        return stats
    
    # Determine which plans to update
    plans_to_update = plan_names if plan_names else list(plan.keys())
    
    # Define the two strategy configurations
    if strategy_type == 'Recreate':
        new_strategy = {
            'type': 'Recreate'
        }
    elif strategy_type == 'RollingUpdate':
        new_strategy = {
            'type': 'RollingUpdate',
            'rolling-update': {
                'max-surge': '2',
                'max-unavailable': '50%'
            }
        }
    else:
        print(f"[ERROR] Invalid strategy type: {strategy_type}")
        return stats
    
    for plan_name in plans_to_update:
        if plan_name not in plan:
            print(f"[WARNING] Plan '{plan_name}' not found in configuration")
            continue
        
        items = plan[plan_name]
        if not isinstance(items, list):
            continue
        
        plan_updated = False
        for item in items:
            if isinstance(item, dict):
                # Only update if the item has a config section with deployment-strategy
                config_section = item.get('config', {})
                if 'deployment-strategy' in config_section:
                    old_strategy = config_section.get('deployment-strategy', {})
                    old_type = old_strategy.get('type') if isinstance(old_strategy, dict) else None
                    
                    # Update the strategy
                    config_section['deployment-strategy'] = new_strategy
                    
                    if old_type != strategy_type:
                        stats['total_updated'] += 1
                        plan_updated = True
        
        if plan_updated:
            stats['plans_affected'] += 1
    
    return stats



def update_resources(config: Dict[str, Any], resources: Dict[str, str], plan_names: List[str] = None) -> Dict[str, int]:
    """
    Update resources values in deployment plans.
    
    Args:
        config: Configuration dictionary
        resources: Dictionary of resource values to update (e.g., {'cpu-min': '1000m', 'memory-max': '4Gi'})
        plan_names: List of specific plan names to update (if None, updates all plans)
    
    Returns:
        Dictionary with statistics about updates made
    """
    stats = {'total_updated': 0, 'plans_affected': 0}
    plan = config.get('plan', {})
    
    if not plan:
        return stats
    
    # Determine which plans to update
    plans_to_update = plan_names if plan_names else list(plan.keys())
    
    # Valid resource keys
    valid_resource_keys = ['cpu-min', 'cpu-max', 'memory-min', 'memory-max']
    
    # Validate resource keys
    for key in resources.keys():
        if key not in valid_resource_keys:
            print(f"[WARNING] Invalid resource key: {key}. Valid keys: {', '.join(valid_resource_keys)}")
    
    for plan_name in plans_to_update:
        if plan_name not in plan:
            print(f"[WARNING] Plan '{plan_name}' not found in configuration")
            continue
        
        items = plan[plan_name]
        if not isinstance(items, list):
            continue
        
        plan_updated = False
        for item in items:
            if isinstance(item, dict):
                # Only update if the item has a config section with resources
                config_section = item.get('config', {})
                if 'resources' in config_section:
                    item_resources = config_section['resources']
                    
                    # Update each specified resource value
                    for resource_key, resource_value in resources.items():
                        if resource_key in valid_resource_keys:
                            old_value = item_resources.get(resource_key)
                            item_resources[resource_key] = resource_value
                            
                            if old_value != resource_value:
                                stats['total_updated'] += 1
                                plan_updated = True
        
        if plan_updated:
            stats['plans_affected'] += 1
    
    return stats


def remove_parameter(config: Dict[str, Any], parameter: str, plan_names: List[str] = None) -> Dict[str, int]:
    """
    Remove a parameter from deployment plans.
    
    Args:
        config: Configuration dictionary
        parameter: Parameter to remove ('auto-pause', 'disabled', or 'deployment-strategy')
        plan_names: List of specific plan names to update (if None, updates all plans)
    
    Returns:
        Dictionary with statistics about removals made
    """
    stats = {'total_removed': 0, 'plans_affected': 0}
    plan = config.get('plan', {})
    
    if not plan:
        return stats
    
    # Determine which plans to update
    plans_to_update = plan_names if plan_names else list(plan.keys())
    
    # Validate parameter name
    valid_params = ['auto-pause', 'disabled', 'deployment-strategy']
    if parameter not in valid_params:
        print(f"[ERROR] Invalid parameter: {parameter}. Must be one of: {', '.join(valid_params)}")
        return stats
    
    for plan_name in plans_to_update:
        if plan_name not in plan:
            print(f"[WARNING] Plan '{plan_name}' not found in configuration")
            continue
        
        items = plan[plan_name]
        if not isinstance(items, list):
            continue
        
        plan_updated = False
        for item in items:
            if isinstance(item, dict):
                if parameter == 'deployment-strategy':
                    # Remove from config section
                    config_section = item.get('config', {})
                    if 'deployment-strategy' in config_section:
                        del config_section['deployment-strategy']
                        stats['total_removed'] += 1
                        plan_updated = True
                else:
                    # Remove from top-level item
                    if parameter in item:
                        del item[parameter]
                        stats['total_removed'] += 1
                        plan_updated = True
        
        if plan_updated:
            stats['plans_affected'] += 1
    
    return stats


def save_yaml(config: Dict[str, Any], file_path: Path) -> None:
    """Save configuration back to YAML file."""
    with open(file_path, 'w') as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False, width=120)


def cmd_list(config_file: Path, show_all: bool = False, show_resources: bool = False) -> int:
    """List deployments and tests."""
    try:
        # Load the configuration file
        config = load_yaml(config_file)
        
        app_name = config.get('app-name', 'unknown')
        print(f"Configuration: {app_name}")
        print(f"File: {config_file}")
        print("=" * 60)
        
        # Get the plan section
        plan = config.get('plan', {})
        
        if not plan:
            print("No plan section found in configuration.")
            return 0
        
        # Extract items based on show_all flag
        if show_all:
            items_to_display = get_all_items(plan)
            print("\nShowing ALL items (enabled and disabled)")
        else:
            items_to_display = get_enabled_items(plan)
            print("\nShowing ENABLED items only (use --all to see disabled items)")
        
        if show_resources:
            print("Showing RESOURCES for each item")
        
        if not items_to_display:
            print("No items found.")
            return 0
        
        # Check for deployment/test mismatches (only for enabled items)
        enabled_items = get_enabled_items(plan)
        warnings = check_deployment_test_mismatch(enabled_items)
        
        # Display results
        total_items = 0
        total_enabled = 0
        total_disabled = 0
        
        for plan_name in sorted(items_to_display.keys()):
            items = items_to_display[plan_name]
            print(f"\n{plan_name}:")
            for item in items:
                item_name = item['name']
                details = []
                
                if 'target' in item:
                    details.append(f"target: {item['target']}")
                
                if 'deployment-strategy' in item:
                    details.append(f"strategy: {item['deployment-strategy']}")
                
                if 'auto-pause' in item:
                    details.append(f"auto-pause: {item['auto-pause']}")
                
                if show_resources and 'resources' in item:
                    res = item['resources']
                    res_parts = []
                    if 'cpu-min' in res:
                        res_parts.append(f"cpu-min: {res['cpu-min']}")
                    if 'cpu-max' in res:
                        res_parts.append(f"cpu-max: {res['cpu-max']}")
                    if 'memory-min' in res:
                        res_parts.append(f"mem-min: {res['memory-min']}")
                    if 'memory-max' in res:
                        res_parts.append(f"mem-max: {res['memory-max']}")
                    if res_parts:
                        details.append(f"resources: [{', '.join(res_parts)}]")
                
                if show_all:
                    details.append(f"disabled: {item['disabled']}")
                    if item['disabled']:
                        total_disabled += 1
                    else:
                        total_enabled += 1
                else:
                    total_enabled += 1
                
                if details:
                    print(f"  - {item_name} ({', '.join(details)})")
                else:
                    print(f"  - {item_name}")
                total_items += 1
        
        print("=" * 60)
        if show_all:
            print(f"Total items: {total_items} ({total_enabled} enabled, {total_disabled} disabled)")
        else:
            print(f"Total enabled items: {total_enabled}")
        
        # Display warnings if any
        if warnings:
            print("\n" + "!" * 60)
            for warning in warnings:
                print(warning)
            print("!" * 60)
        
        return 0
    
    except Exception as e:
        print(f"[ERROR] Failed to process {config_file}: {str(e)}")
        import traceback
        traceback.print_exc()
        return 1


def cleanup_yaml_structure(config: Dict[str, Any]) -> tuple:
    """
    Cleanup and optimize YAML structure by identifying repeated structures.
    """
    from collections import defaultdict
    import hashlib
    import json
    
    plan = config.get('plan', {})
    if not plan:
        return config, {}, {'resources_anchored': 0, 'health_checks_anchored': 0, 
                           'annotations_anchored': 0, 'strategies_anchored': 0, 'total_anchors': 0}
    
    # Track unique structures
    resource_configs = defaultdict(list)
    health_check_configs = defaultdict(list)
    annotation_configs = defaultdict(list)
    deployment_strategy_configs = defaultdict(list)
    
    # Identify unique structures
    for plan_name, items in plan.items():
        if not isinstance(items, list):
            continue
        
        for idx, item in enumerate(items):
            if not isinstance(item, dict):
                continue
            
            config_section = item.get('config', {})
            
            if 'resources' in config_section:
                res = config_section['resources']
                res_hash = hashlib.md5(json.dumps(res, sort_keys=True).encode()).hexdigest()[:8]
                resource_configs[res_hash].append((plan_name, idx, res))
            
            if 'health-check' in config_section:
                hc = config_section['health-check']
                hc_hash = hashlib.md5(json.dumps(hc, sort_keys=True).encode()).hexdigest()[:8]
                health_check_configs[hc_hash].append((plan_name, idx, hc))
            
            if 'annotations' in config_section:
                ann = config_section['annotations']
                ann_hash = hashlib.md5(json.dumps(ann, sort_keys=True).encode()).hexdigest()[:8]
                annotation_configs[ann_hash].append((plan_name, idx, ann))
            
            if 'deployment-strategy' in config_section:
                ds = config_section['deployment-strategy']
                ds_hash = hashlib.md5(json.dumps(ds, sort_keys=True).encode()).hexdigest()[:8]
                deployment_strategy_configs[ds_hash].append((plan_name, idx, ds))
    
    # Create anchor mapping
    anchor_map = {}
    
    for res_hash, usages in resource_configs.items():
        if len(usages) > 1:
            first_plan = usages[0][0]
            anchor_base = first_plan.replace('-', '_')
            anchor_name = f"{anchor_base}_resources"
            anchor_map[f"resources_{res_hash}"] = (anchor_name, usages[0][2])
    
    for hc_hash, usages in health_check_configs.items():
        if len(usages) > 1:
            first_plan = usages[0][0]
            anchor_base = first_plan.replace('-', '_')
            anchor_name = f"{anchor_base}_health_check"
            anchor_map[f"health_check_{hc_hash}"] = (anchor_name, usages[0][2])
    
    for ann_hash, usages in annotation_configs.items():
        if len(usages) > 1:
            first_plan = usages[0][0]
            anchor_base = first_plan.replace('-', '_')
            anchor_name = f"{anchor_base}_annotations"
            anchor_map[f"annotations_{ann_hash}"] = (anchor_name, usages[0][2])
    
    for ds_hash, usages in deployment_strategy_configs.items():
        if len(usages) > 1:
            first_plan = usages[0][0]
            anchor_base = first_plan.replace('-', '_')
            strategy_type = usages[0][2].get('type', 'unknown').lower()
            anchor_name = f"{anchor_base}_strategy_{strategy_type}"
            anchor_map[f"deployment_strategy_{ds_hash}"] = (anchor_name, usages[0][2])
    
    stats = {
        'resources_anchored': sum(1 for usages in resource_configs.values() if len(usages) > 1),
        'health_checks_anchored': sum(1 for usages in health_check_configs.values() if len(usages) > 1),
        'annotations_anchored': sum(1 for usages in annotation_configs.values() if len(usages) > 1),
        'strategies_anchored': sum(1 for usages in deployment_strategy_configs.values() if len(usages) > 1),
        'total_anchors': len(anchor_map)
    }
    
    return config, anchor_map, stats


def format_yaml_value(value):
    """Format a value for YAML output."""
    if isinstance(value, bool):
        return str(value).lower()
    elif isinstance(value, str):
        if value.isdigit() or ':' in value or value in ['true', 'false']:
            return f"'{value}'"
        return value
    return str(value)


def build_yaml_with_anchors(config, anchor_map):
    """Build YAML string with proper anchors and references."""
    import hashlib
    import json
    
    lines = []
    
    # Add header
    lines.append(f"app-name: {config.get('app-name', 'unknown')}")
    if 'docker-image' in config:
        lines.append(f"docker-image: {config['docker-image']}")
    
    # Add environment-variables
    if 'environment-variables' in config:
        lines.append("environment-variables:")
        env_vars = config['environment-variables']
        if 'inherits_from' in env_vars and env_vars['inherits_from']:
            lines.append("  inherits_from:")
            for item in env_vars['inherits_from']:
                lines.append(f"    - {item}")
        if 'overrides' in env_vars:
            overrides = env_vars['overrides']
            if overrides is None or (isinstance(overrides, dict) and len(overrides) == 0):
                # Empty or None overrides - output as empty object
                lines.append("  overrides: {}")
            else:
                lines.append("  overrides:")
                for key, value in overrides.items():
                    lines.append(f"    {key}: {format_yaml_value(value)}")
    
    # Build hash to anchor mapping
    hash_to_anchor = {}
    for key, (anchor_name, anchor_config) in anchor_map.items():
        cfg_hash = hashlib.md5(json.dumps(anchor_config, sort_keys=True).encode()).hexdigest()[:8]
        config_type = key.split('_')[0]
        hash_to_anchor[cfg_hash] = (anchor_name, config_type)
    
    defined_anchors = set()
    
    lines.append("")
    lines.append("plan:")
    
    plan = config.get('plan', {})
    
    # Sort plan names with test plans at the end
    def sort_plans(plan_name):
        # Extract the numeric prefix if it exists
        import re
        match = re.match(r'^(\d+)-', plan_name)
        if match:
            number = int(match.group(1))
        else:
            number = 999  # Put non-numbered plans at the end
        
        # Check if it's a test plan
        is_test = '-test' in plan_name.lower()
        
        # Return tuple for sorting: (is_test, number, name)
        # This ensures non-test plans come first, then test plans,
        # and within each group they're sorted by number
        return (is_test, number, plan_name)
    
    sorted_plan_names = sorted(plan.keys(), key=sort_plans)
    
    for plan_name in sorted_plan_names:
        items = plan[plan_name]
        if not isinstance(items, list):
            continue
        
        lines.append(f"  {plan_name}:")
        
        for item in items:
            if not isinstance(item, dict):
                continue
            
            lines.append(f"    - name: {item.get('name', 'unnamed')}")
            
            # Top-level fields
            for field in ['platform', 'disabled', 'app-name-override', 'auto-pause']:
                if field in item:
                    lines.append(f"      {field}: {format_yaml_value(item[field])}")
            
            if 'config' in item:
                lines.append("      config:")
                config_section = item['config']
                
                def add_field_with_anchor(field_name):
                    if field_name not in config_section:
                        return
                    
                    cfg = config_section[field_name]
                    
                    # Handle empty dictionaries specially
                    if isinstance(cfg, dict) and not cfg:
                        lines.append(f"        {field_name}: {{}}")
                        return
                    
                    cfg_hash = hashlib.md5(json.dumps(cfg, sort_keys=True).encode()).hexdigest()[:8]
                    
                    if cfg_hash in hash_to_anchor:
                        anchor_name, _ = hash_to_anchor[cfg_hash]
                        if anchor_name not in defined_anchors:
                            lines.append(f"        {field_name}: &{anchor_name}")
                            add_field_content(cfg, field_name)
                            defined_anchors.add(anchor_name)
                        else:
                            lines.append(f"        {field_name}: *{anchor_name}")
                    else:
                        lines.append(f"        {field_name}:")
                        add_field_content(cfg, field_name)
                
                def add_field_content(cfg, field_name):
                    if field_name == 'resources':
                        for k in ['cpu-min', 'cpu-max', 'memory-min', 'memory-max']:
                            if k in cfg:
                                lines.append(f"          {k}: {cfg[k]}")
                    elif field_name == 'health-check':
                        for check_type in ['liveness', 'readiness']:
                            if check_type in cfg:
                                lines.append(f"          {check_type}:")
                                check = cfg[check_type]
                                if 'http' in check:
                                    lines.append("            http:")
                                    for k in ['failure-threshold', 'initial-delay-seconds', 'path', 'period-seconds', 'timeout-seconds']:
                                        if k in check['http']:
                                            lines.append(f"              {k}: {format_yaml_value(check['http'][k])}")
                                if 'type' in check:
                                    lines.append(f"            type: {check['type']}")
                    elif field_name == 'annotations':
                        for k, v in cfg.items():
                            lines.append(f"          {k}: {format_yaml_value(v)}")
                    elif field_name == 'deployment-strategy':
                        if 'type' in cfg:
                            lines.append(f"          type: {cfg['type']}")
                        if 'rolling-update' in cfg:
                            lines.append("          rolling-update:")
                            for k, v in cfg['rolling-update'].items():
                                lines.append(f"            {k}: {format_yaml_value(v)}")
                    elif field_name == 'labels':
                        if not cfg:  # Empty dictionary
                            # Don't add any content, will be handled as empty object
                            pass
                        else:
                            for k, v in cfg.items():
                                lines.append(f"          {k}: {format_yaml_value(v)}")
                
                def add_trex_field(trex_list):
                    """Add trex field with proper formatting."""
                    lines.append("        trex:")
                    for trex_item in trex_list:
                        lines.append("          - autoProvisionApproach: " + str(trex_item.get('autoProvisionApproach', 'None')))
                        if 'environmentType' in trex_item:
                            lines.append("            environmentType: " + str(trex_item['environmentType']))
                        if 'region' in trex_item:
                            lines.append("            region: " + str(trex_item['region']))
                        if 'serviceCode' in trex_item:
                            lines.append("            serviceCode: " + str(trex_item['serviceCode']))
                        
                        if 'serviceEndPoint' in trex_item:
                            sep = trex_item['serviceEndPoint']
                            lines.append("            serviceEndPoint:")
                            if 'address' in sep:
                                lines.append("              address: " + str(sep['address']))
                            if 'healthCheck' in sep:
                                hc = sep['healthCheck']
                                lines.append("              healthCheck:")
                                for hc_key in ['address', 'port', 'protocol', 'urlPath']:
                                    if hc_key in hc:
                                        lines.append(f"                {hc_key}: {format_yaml_value(hc[hc_key])}")
                            for sep_key in ['host', 'port', 'protocol', 'serviceType', 'status']:
                                if sep_key in sep:
                                    lines.append(f"              {sep_key}: {format_yaml_value(sep[sep_key])}")
                        
                        if 'serviceType' in trex_item:
                            lines.append("            serviceType: " + str(trex_item['serviceType']))
                        if 'status' in trex_item:
                            lines.append("            status: " + str(trex_item['status']))
                        if 'supportedEnvironment' in trex_item:
                            lines.append("            supportedEnvironment:")
                            for env in trex_item['supportedEnvironment']:
                                lines.append(f"              - {env}")
                        if 'troxRoutable' in trex_item:
                            lines.append("            troxRoutable: " + str(trex_item['troxRoutable']).lower())
                
                # Add fields in order - with labels first if present
                if 'labels' in config_section:
                    add_field_with_anchor('labels')
                
                # Add annotations with anchors
                add_field_with_anchor('annotations')
                
                # Add deployment strategy with anchors
                add_field_with_anchor('deployment-strategy')
                
                # Add replicas if present
                if 'replicas' in config_section:
                    lines.append(f"        replicas: {config_section['replicas']}")
                
                # Add resources with anchors
                add_field_with_anchor('resources')
                
                # Add environment variables if present (for test configurations)
                if 'environment' in config_section:
                    lines.append("        environment:")
                    for k, v in config_section['environment'].items():
                        lines.append(f"          {k}: {format_yaml_value(v)}")
                
                # Add health-check with anchors
                add_field_with_anchor('health-check')
                
                # Add timeout if present
                if 'timeout' in config_section:
                    lines.append(f"        timeout: {config_section['timeout']}")
                
                # Add nodeSelector if present
                if 'nodeSelector' in config_section:
                    lines.append("        nodeSelector:")
                    for k, v in config_section['nodeSelector'].items():
                        lines.append(f"          {k}: {format_yaml_value(v)}")
                
                # Add workload-identity if present
                if 'workload-identity' in config_section:
                    lines.append("        workload-identity:")
                    for k, v in config_section['workload-identity'].items():
                        lines.append(f"          {k}: {format_yaml_value(v)}")
                
                # Add trex if present (important!)
                if 'trex' in config_section:
                    add_trex_field(config_section['trex'])
                
                # Add image and tag for test configurations
                if 'image' in config_section:
                    lines.append(f"        image: {config_section['image']}")
                if 'tag' in config_section:
                    lines.append(f"        tag: {config_section['tag']}")
                if 'target' in config_section:
                    lines.append(f"        target: {config_section['target']}")
            
            # Add task field if present
            if 'task' in item:
                lines.append(f"      task: {format_yaml_value(item['task'])}")
    
    if 'settings-profile' in config:
        lines.append("")
        lines.append(f"settings-profile: {config['settings-profile']}")
    
    return '\n'.join(lines) + '\n'


def cmd_cleanup(config_file: Path, output_file: Path = None, dry_run: bool = False) -> int:
    """Cleanup and optimize YAML structure with anchors."""
    try:
        config = load_yaml(config_file)
        
        app_name = config.get('app-name', 'unknown')
        print(f"Configuration: {app_name}")
        print(f"File: {config_file}")
        print("=" * 60)
        
        print("\n[ANALYZING] Identifying repeated structures...")
        optimized_config, anchor_map, stats = cleanup_yaml_structure(config)
        
        print(f"\n[FOUND] Optimization opportunities:")
        print(f"  - Resources: {stats['resources_anchored']} unique configurations")
        print(f"  - Health checks: {stats['health_checks_anchored']} unique configurations")
        print(f"  - Annotations: {stats['annotations_anchored']} unique configurations")
        print(f"  - Deployment strategies: {stats['strategies_anchored']} unique configurations")
        print(f"  - Total anchors to create: {stats['total_anchors']}")
        
        if dry_run:
            print("\n[DRY RUN] No changes made. Remove --dry-run to apply changes.")
            return 0
        
        if output_file is None:
            output_file = config_file.parent / f"{config_file.stem}.cleaned{config_file.suffix}"
        
        print(f"\n[GENERATING] Creating optimized YAML with anchors...")
        optimized_yaml = build_yaml_with_anchors(config, anchor_map)
        
        # Write output
        with open(output_file, 'w') as f:
            f.write(optimized_yaml)
        
        print(f"[SUCCESS] Optimized configuration saved to {output_file}")
        
        # Show file size comparison
        import os
        original_size = os.path.getsize(config_file)
        optimized_size = os.path.getsize(output_file)
        reduction = original_size - optimized_size
        reduction_pct = (reduction / original_size) * 100 if original_size > 0 else 0
        
        print(f"\nFile size comparison:")
        print(f"  Original:  {original_size:,} bytes")
        print(f"  Optimized: {optimized_size:,} bytes")
        if reduction > 0:
            print(f"  Reduction: {reduction:,} bytes ({reduction_pct:.1f}%)")
        else:
            print(f"  Change:    {abs(reduction):,} bytes ({abs(reduction_pct):.1f}% increase)")
        
        return 0
    
    except Exception as e:
        print(f"[ERROR] Failed to cleanup {config_file}: {str(e)}")
        import traceback
        traceback.print_exc()
        return 1


def cmd_update(config_file: Path, auto_pause: bool = None, disabled: bool = None, 
               deployment_strategy: str = None, resources: Dict[str, str] = None,
               remove_param: str = None, plan_names: List[str] = None) -> int:
    """Update configuration values."""
    try:
        # Load the configuration file
        config = load_yaml(config_file)
        
        app_name = config.get('app-name', 'unknown')
        print(f"Configuration: {app_name}")
        print(f"File: {config_file}")
        print("=" * 60)
        
        changes_made = False
        
        # Update auto-pause if requested
        if auto_pause is not None:
            print(f"\nUpdating auto-pause to: {auto_pause}")
            if plan_names:
                print(f"Target plans: {', '.join(plan_names)}")
            else:
                print("Target plans: ALL")
            
            stats = update_auto_pause(config, auto_pause, plan_names)
            
            print(f"\nUpdated {stats['total_updated']} items across {stats['plans_affected']} plan(s)")
            changes_made = True
        
        # Update disabled if requested
        if disabled is not None:
            print(f"\nUpdating disabled to: {disabled}")
            if plan_names:
                print(f"Target plans: {', '.join(plan_names)}")
            else:
                print("Target plans: ALL")
            
            stats = update_disabled(config, disabled, plan_names)
            
            print(f"\nUpdated {stats['total_updated']} items across {stats['plans_affected']} plan(s)")
            changes_made = True
        
        # Update deployment-strategy if requested
        if deployment_strategy is not None:
            print(f"\nUpdating deployment-strategy to: {deployment_strategy}")
            if plan_names:
                print(f"Target plans: {', '.join(plan_names)}")
            else:
                print("Target plans: ALL")
            
            stats = update_deployment_strategy(config, deployment_strategy, plan_names)
            
            print(f"\nUpdated {stats['total_updated']} items across {stats['plans_affected']} plan(s)")
            changes_made = True
        
        # Update resources if requested
        if resources is not None:
            print(f"\nUpdating resources:")
            for key, value in resources.items():
                print(f"  {key}: {value}")
            if plan_names:
                print(f"Target plans: {', '.join(plan_names)}")
            else:
                print("Target plans: ALL")
            
            stats = update_resources(config, resources, plan_names)
            
            print(f"\nUpdated {stats['total_updated']} resource values across {stats['plans_affected']} plan(s)")
            changes_made = True
        
        # Remove parameter if requested
        if remove_param is not None:
            print(f"\nRemoving parameter: {remove_param}")
            if plan_names:
                print(f"Target plans: {', '.join(plan_names)}")
            else:
                print("Target plans: ALL")
            
            stats = remove_parameter(config, remove_param, plan_names)
            
            print(f"\nRemoved {stats['total_removed']} parameters across {stats['plans_affected']} plan(s)")
            changes_made = True
        
        # Save the file if changes were made
        if changes_made:
            save_yaml(config, config_file)
            print(f"\n[SUCCESS] Configuration saved to {config_file}")
        else:
            print("\n[INFO] No changes made")
        
        return 0
    
    except Exception as e:
        print(f"[ERROR] Failed to update {config_file}: {str(e)}")
        import traceback
        traceback.print_exc()
        return 1


def main():
    parser = argparse.ArgumentParser(
        description='General-purpose deployment configuration tool',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  List enabled deployments:
    %(prog)s list service-datascience-gateway-ga.yml
  
  List all deployments (including disabled):
    %(prog)s list service-datascience-gateway-ga.yml --all
  
  List with resource values:
    %(prog)s list service-datascience-gateway-ga.yml --resources
    %(prog)s list service-datascience-gateway-ga.yml --all --resources
  
  Update auto-pause for all plans:
    %(prog)s update service-datascience-gateway-ga.yml --auto-pause false
  
  Update disabled for specific plans:
    %(prog)s update service-datascience-gateway-ga.yml --disabled true --plans 5-ga-deploy
  
  Update deployment strategy:
    %(prog)s update service-datascience-gateway-ga.yml --deployment-strategy Recreate --plans 5-ga-deploy
    %(prog)s update service-datascience-gateway-ga.yml --deployment-strategy RollingUpdate --plans 5-ga-deploy
  
  Update resources:
    %(prog)s update service-datascience-gateway-ga.yml --cpu-min 1000m --memory-max 4Gi --plans 5-ga-deploy
    %(prog)s update service-datascience-gateway-ga.yml --memory-min 2Gi --memory-max 8Gi
  
  Remove a parameter:
    %(prog)s update service-datascience-gateway-ga.yml --remove auto-pause --plans 5-ga-deploy
    %(prog)s update service-datascience-gateway-ga.yml --remove deployment-strategy --plans 5-ga-deploy
  
  Update multiple fields:
    %(prog)s update service-datascience-gateway-ga.yml --auto-pause false --disabled false --deployment-strategy RollingUpdate --cpu-min 1000m --plans 5-ga-deploy
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Command to execute')
    
    # List command
    list_parser = subparsers.add_parser('list', help='List deployments and tests')
    list_parser.add_argument('config_file', type=Path, help='Configuration file path')
    list_parser.add_argument('--all', action='store_true', 
                            help='Show all items including disabled ones')
    list_parser.add_argument('--resources', action='store_true',
                            help='Show resource values (cpu-min, cpu-max, memory-min, memory-max)')
    
    # Cleanup command
    cleanup_parser = subparsers.add_parser('cleanup', help='Cleanup and optimize YAML structure with anchors')
    cleanup_parser.add_argument('config_file', type=Path, help='Configuration file path')
    cleanup_parser.add_argument('--output', type=Path, help='Output file (default: input file with .cleaned.yml suffix)')
    cleanup_parser.add_argument('--dry-run', action='store_true', help='Show what would be done without making changes')
    
    # Update command
    update_parser = subparsers.add_parser('update', help='Update configuration values')
    update_parser.add_argument('config_file', type=Path, help='Configuration file path')
    update_parser.add_argument('--auto-pause', type=str, choices=['true', 'false'],
                               help='Set auto-pause value (true/false)')
    update_parser.add_argument('--disabled', type=str, choices=['true', 'false'],
                               help='Set disabled value (true/false)')
    update_parser.add_argument('--deployment-strategy', type=str, 
                               choices=['Recreate', 'RollingUpdate'],
                               help='Set deployment strategy (Recreate or RollingUpdate)')
    update_parser.add_argument('--cpu-min', type=str,
                               help='Set minimum CPU (e.g., 500m, 1000m)')
    update_parser.add_argument('--cpu-max', type=str,
                               help='Set maximum CPU (e.g., 2000m, 4000m)')
    update_parser.add_argument('--memory-min', type=str,
                               help='Set minimum memory (e.g., 512Mi, 1Gi)')
    update_parser.add_argument('--memory-max', type=str,
                               help='Set maximum memory (e.g., 2Gi, 4Gi)')
    update_parser.add_argument('--remove', type=str, 
                               choices=['auto-pause', 'disabled', 'deployment-strategy'],
                               help='Remove a parameter from items')
    update_parser.add_argument('--plans', type=str,
                               help='Comma-separated list of plan names to update (default: all plans)')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    config_file = args.config_file
    
    if not config_file.exists():
        print(f"[ERROR] File not found: {config_file}")
        return 1
    
    if args.command == 'list':
        return cmd_list(config_file, show_all=args.all, show_resources=args.resources)
    
    elif args.command == 'cleanup':
        output_file = args.output if hasattr(args, 'output') else None
        dry_run = args.dry_run if hasattr(args, 'dry_run') else False
        return cmd_cleanup(config_file, output_file=output_file, dry_run=dry_run)
    
    elif args.command == 'update':
        # Parse auto-pause value
        auto_pause = None
        if args.auto_pause:
            auto_pause = args.auto_pause.lower() == 'true'
        
        # Parse disabled value
        disabled = None
        if args.disabled:
            disabled = args.disabled.lower() == 'true'
        
        # Parse deployment-strategy value
        deployment_strategy = args.deployment_strategy if hasattr(args, 'deployment_strategy') else None
        
        # Parse resources values
        resources = {}
        if hasattr(args, 'cpu_min') and args.cpu_min:
            resources['cpu-min'] = args.cpu_min
        if hasattr(args, 'cpu_max') and args.cpu_max:
            resources['cpu-max'] = args.cpu_max
        if hasattr(args, 'memory_min') and args.memory_min:
            resources['memory-min'] = args.memory_min
        if hasattr(args, 'memory_max') and args.memory_max:
            resources['memory-max'] = args.memory_max
        
        # Only pass resources if at least one was specified
        resources = resources if resources else None
        
        # Parse remove parameter
        remove_param = args.remove if hasattr(args, 'remove') else None
        
        # Parse plan names
        plan_names = None
        if args.plans:
            plan_names = [p.strip() for p in args.plans.split(',')]
        
        return cmd_update(config_file, auto_pause=auto_pause, disabled=disabled, 
                         deployment_strategy=deployment_strategy, resources=resources,
                         remove_param=remove_param, plan_names=plan_names)

if __name__ == '__main__':
    sys.exit(main())
