# LinkedIn Summary for Tom Mackall

## Option 1: Conversational/Approachable

DevOps Engineer and Test Automation Architect with a track record of building CI/CD pipelines, release engineering infrastructure, and test automation frameworks for enterprise teams.

Currently leading DevOps initiatives for an AI development team—things like migrating from GitFlow to GitHub Flow, transitioning secrets management from Vault to Google Secret Manager, and building GitHub Actions workflows for 20+ microservices across multiple Kubernetes environments (GKE and on-prem).

What I bring to the table:
→ CI/CD pipeline design and implementation (GitHub Actions)
→ Kubernetes operations and troubleshooting
→ Test automation architecture (Node.js, Mocha, Chai)
→ Release engineering and production deployment workflows
→ Leading technical migrations and process improvements

I'm exploring contract opportunities where I can help teams modernize their DevOps practices, improve release processes, or build out test automation. Open to remote work.

Let's connect—happy to chat about how I might help your team.

---

## Option 2: More Direct/Professional

DevOps Engineer | Test Automation Architect | Release Engineering Lead

I help engineering teams ship faster and more reliably through well-designed CI/CD pipelines, test automation, and release engineering practices.

Current focus areas:
• CI/CD pipeline implementation (GitHub Actions, GitOps workflows)
• Kubernetes environments (GKE, on-prem)
• Test automation frameworks (Node.js, Mocha, Chai)
• Secrets management (Google Secret Manager, HashiCorp Vault)
• Technical migrations and process modernization

Recent work includes leading a GitFlow-to-GitHub-Flow migration, transitioning secrets management to GSM, and building system test workflows for 20+ microservices deployed across multiple GKE environments.

Available for contract engagements. Open to remote opportunities.

---

## Headline Options (120 characters max)

1. DevOps Engineer | Test Automation | Release Engineering | Available for Contract Work

2. DevOps Engineer & Test Automation Architect | CI/CD | Kubernetes | Open to Contracts

3. DevOps | Release Engineering | Test Automation | Seeking Contract Opportunities

---

## Tips for LinkedIn Profile

- Set "Open to Work" (visible to recruiters only if you prefer discretion)
- Use a professional headshot
- Add skills: GitHub Actions, Kubernetes, GKE, CI/CD, DevOps, Test Automation, Node.js, Python, Bash
- Request recommendations from former colleagues if possible
- Match your job titles to the resume (e.g., "DevOps Engineer / Test Automation Lead" at UKG)
